# Morda
## Simple jQuery slider for your website
* Responsive. iOS and Android tested
* Swipe events supported
* Keyboard arrows supported
* Smooth animation
* SVG images. Retina ready
* All in one JavaScript file

##### Demo and docs: [ini.one/morda](http://ini.one/morda/)
