<?php 
$con= mysql_connect("localhost","etech","rETF4uVv6yNK") or die(mysql_error());

mysql_select_db("etech_yogesh",$con) or die(mysql_error());

?>
