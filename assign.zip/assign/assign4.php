<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>assignment4</title>


  
<script src="Scripts/jquery_1_4_2_head.js"></script>
<script src="Scripts/jquery_checkall_1_0_forjquery_1_4_2_head.js"></script>
</head>
<body >
<!------
<ul>
    <li>
        <input type="checkbox" name="level-1">Level 1</input>
        <ul>
            <li>
                <input type="checkbox" name="level-2">Level 2</input>
                <ul>
                    <li><input type="checkbox" name="level-3">Level 3</input></li>
                    <li><input type="checkbox" name="level-3">Level 3</input></li>
                    <li><input type="checkbox" name="level-3">Level 3</input></li>
                    <li><input type="checkbox" name="level-3">Level 3</input></li>                    
                </ul>
            </li>
        </ul>
    </li>
</ul> 
<form id="theform">
    <label>Parent</label><input name="group1" type="checkbox" value="parent1" class="parent" />
    <label>Child 1</label><input name="group1" type="checkbox" value="child1" class="child" />
    <label>Child 2</label><input name="group1" type="checkbox" value="child2" class="child" />
    <label>Child 3</label><input name="group1" type="checkbox" value="child3" class="child" />
</form>----->





<form>

<fieldset>
	<input type="checkbox" class="parentCheckBox" /> Parent 1<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-1<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-2<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-3<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-4<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-5<br />
</fieldset>

</form>

</body>
</html>
