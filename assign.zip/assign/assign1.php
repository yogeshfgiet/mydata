<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>assignment1</title>
</head>
<body>
    
    <script src="jquery-1.12.0.min.js"></script>
    <script>
window.onload = function() {
 
    alert( "welcome" );
 
};

$( document ).ready(function() {
 
    $( "#at" ).click(function( event ) {
 
        alert( "Thanks for visiting!" );
 
    });
 
});


   
 
    </script>



<a id="at" href="#">Hello </a> 

</body>
</html>
