<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>assignment1</title>
 <link rel="stylesheet" href="style.css" type="text/css" >
</head>
<body>
    
    <script src="jquery-1.12.0.min.js"></script>
    <script>


 
 
    </script>


<div class="a1">
  <a id="aa" href="assign1.php">Simple Alert  </a> </div>
	<div class="a2"><a id="aa" href="assign2.php">Validation</a> </div>

	<div class="a3"><a id="aa" href="assign3.php">Mouse Effect </a>  </div>
	<div class="a4"><a id="aa" href="checkdemo.php">Check Box </a>  </div>
	<div class="a5"><a id="aa" href="assign5.php">Drop Down </a> </div>
	<div class="a5"><a id="aa" href="table.php">Fatch data With AJAX </a> </div>
	
</body>
</html>
