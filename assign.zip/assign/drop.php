<html>
<head>
<script src="Scripts/jquery_1_4_2_head.js"></script>
<script src="Scripts/jquery_checkall_1_0_forjquery_1_4_2_head.js"></script>
</head>
<body>
<form>



<fieldset>
	<input type="checkbox" class="parentCheckBox" /> Parent 1<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-1<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-2<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-3<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-4<br />
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="childCheckBox" /> Child 1-5<br />
</fieldset>


</form>
</body>
