<!doctype html>
<html>
<head>
  
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    <title>assignment1</title>
	<!-----------------Boot Strap -------------->


 <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="css/bootstrap.css.map" rel="stylesheet">

   <link href="css/bootstrap.min.css.map" rel="stylesheet">
   <link href="css/bootstrap-theme.css" rel="stylesheet">  
 <link href="css/bootstrap-theme.css.map" rel="stylesheet">  
 <link href="css/bootstrap-theme.min.css" rel="stylesheet">
 <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">

 <!-- Bootstrap js -->
    <link href="js/bootstrap.js" rel="stylesheet">
   
    <link href="js/bootstrap.min.js" rel="stylesheet">
<link href="js/npm.js" rel="stylesheet">	

<!-----------------Boot Strap -------------->


 
    <script src="jquery-1.12.0.min.js"></script>
    <script>
window.onload = function() {
 
    alert( "welcome To Assignment" );
 
};

$( document ).ready(function() {
 
    $( "#at" ).click(function( event ) {
 
        alert( "Thanks for visiting!" );
 
    });
 
});


   
 
    </script>
</head>
<body>
 <div class="container">

	<div class="panel panel-default col-lg-4" >
 	   <div class="panel-heading" > <Strong> Simple Alert </strong></div>
    	   <div class="panel-body">

		<a id="at" href="#"><div class="well">Please Click Here </div></a><br>
		
	 </div>
		<a id="aa" href="index.php">Click Here to main menu</a> 
    </div>
 </div>



</body>
</html>
