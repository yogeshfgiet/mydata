<!doctype html>
<html>
<head>
       
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Mouse Effect</title>
	
 <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="css/bootstrap.css.map" rel="stylesheet">

   <link href="css/bootstrap.min.css.map" rel="stylesheet">
   <link href="css/bootstrap-theme.css" rel="stylesheet">  
 <link href="css/bootstrap-theme.css.map" rel="stylesheet">  
 <link href="css/bootstrap-theme.min.css" rel="stylesheet">
 <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">

 <!-- Bootstrap js -->
    <link href="js/bootstrap.js" rel="stylesheet">
   
    <link href="js/bootstrap.min.js" rel="stylesheet">
<link href="js/npm.js" rel="stylesheet">	

<!-----------------Boot Strap -------------->
  <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
 <link href="Nivo-Slider-master/nivo-slider.css" rel="stylesheet" type="text/css"/>
      
        <script src="Nivo-Slider-master/jquery.nivo.slider.js" type="text/javascript"></script>
        <link href="Nivo-Slider-master/themes/default/default.css" rel="stylesheet" type="text/css"/>
    <script>

    $(window).load(function() {
                $('#slider').nivoSlider();
            });
    </script>
</head>
<body>


<div class="container">

	<div class="panel panel-default col-lg-8" >
 	   <div class="panel-heading" > <Strong>Facy Box</strong></div>
    	   <div class="panel-body">

		<div class="hello"><h3>Nivo Slider</h3>	</div>
       	 <div id="slider">
            <img src="images/1.jpeg" alt="" />
            <img src="images/2.jpeg" alt=""  />
            <img src="images/3.jpeg" alt=""  />
            <img src="images/4.jpeg" alt=""/>
	    <img src="images/5.jpeg" alt=""/>
        </div>
        <div id="htmlcaption" class="nivo-html-caption">

           
        </div>
   	 </div>


	</div>

</div>

</body>
</html>
