<?php 
$con= mysql_connect("localhost","root","123") or die(mysql_error());

mysql_select_db("test",$con) or die(mysql_error());

?>
