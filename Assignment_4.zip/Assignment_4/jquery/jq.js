//
//$(document).ready(function (){
//    ($("#c1Id") ).click(function (){
//    
//    if(($("#c1Id").prop('checked')== true) || ($("#c2Id").prop('checked')== true) || ($("#c3Id").prop('checked')== true)){
//        
//        $("#p1Id").prop("checked",true);
//             }else{
//                 $("#p1Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#c2Id") ).click(function (){
//    
//    if(($("#c1Id").prop('checked')== true) || ($("#c2Id").prop('checked')== true) || ($("#c3Id").prop('checked')== true)){
//        
//        $("#p1Id").prop("checked",true);
//             }else{
//                 $("#p1Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#c3Id") ).click(function (){
//    
//    if(($("#c1Id").prop('checked')== true) || ($("#c2Id").prop('checked')== true) || ($("#c3Id").prop('checked')== true)){
//        
//        $("#p1Id").prop("checked",true);
//             }else{
//                 $("#p1Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#p1Id") ).click(function (){
//        if($("#p1Id").prop("checked") == true){
//        $("#c1Id").prop("checked",true);
//        $("#c2Id").prop("checked",true);
//        $("#c3Id").prop("checked",true);
//         } else{
//             $("#c1Id").prop("checked",false);
//             $("#c2Id").prop("checked",false);
//             $("#c3Id").prop("checked",false);
//         }   
//            });
//});
//
////==============================================================================
//
//$(document).ready(function (){
//    ($("#cc1Id") ).click(function (){
//    
//    if(($("#cc1Id").prop('checked')== true) || ($("#cc2Id").prop('checked')== true) ||
//            ($("#cc3Id").prop('checked')== true) || ($("#cc4Id").prop('checked')== true)){
//        
//        $("#p2Id").prop("checked",true);
//             }else{
//                 $("#p2Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#cc2Id") ).click(function (){
//    
//    if(($("#cc1Id").prop('checked')== true) || ($("#cc2Id").prop('checked')== true) ||
//            ($("#cc3Id").prop('checked')== true) || ($("#cc4Id").prop('checked')== true)){
//        
//        $("#p2Id").prop("checked",true);
//             }else{
//                 $("#p2Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#cc3Id") ).click(function (){
//    
//    if(($("#cc1Id").prop('checked')== true) || ($("#cc2Id").prop('checked')== true) || 
//            ($("#cc3Id").prop('checked')== true) || ($("#cc4Id").prop('checked')== true)){
//        
//        $("#p2Id").prop("checked",true);
//             }else{
//                 $("#p2Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#cc4Id") ).click(function (){
//    
//    if(($("#cc1Id").prop('checked')== true) || ($("#cc2Id").prop('checked')== true) ||
//            ($("#cc3Id").prop('checked')== true) || ($("#cc4Id").prop('checked')== true)){
//        
//        $("#p2Id").prop("checked",true);
//             }else{
//                 $("#p2Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#p2Id") ).click(function (){
//        if($("#p2Id").prop("checked") == true){
//        $("#cc1Id").prop("checked",true);
//        $("#cc2Id").prop("checked",true);
//        $("#cc3Id").prop("checked",true);
//        $("#cc4Id").prop("checked",true);
//         } else{
//             $("#cc1Id").prop("checked",false);
//             $("#cc2Id").prop("checked",false);
//             $("#cc3Id").prop("checked",false);
//             $("#cc4Id").prop("checked",false);
//         }   
//            });
//});
//
////==============================================================================
//
//$(document).ready(function (){
//    ($("#ccc1Id") ).click(function (){
//    
//    if(($("#ccc1Id").prop('checked')== true) || ($("#ccc2Id").prop('checked')== true) || ($("#ccc3Id").prop('checked')== true)){
//        
//        $("#p3Id").prop("checked",true);
//             }else{
//                 $("#p3Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#ccc2Id") ).click(function (){
//    
//    if(($("#ccc1Id").prop('checked')== true) || ($("#ccc2Id").prop('checked')== true) || ($("#ccc3Id").prop('checked')== true)){
//        
//        $("#p3Id").prop("checked",true);
//             }else{
//                 $("#p3Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#ccc3Id") ).click(function (){
//    
//    if(($("#ccc1Id").prop('checked')== true) || ($("#ccc2Id").prop('checked')== true) || ($("#ccc3Id").prop('checked')== true)){
//        
//        $("#p3Id").prop("checked",true);
//             }else{
//                 $("#p3Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#p3Id") ).click(function (){
//        if($("#p3Id").prop("checked") == true){
//        $("#ccc1Id").prop("checked",true);
//        $("#ccc2Id").prop("checked",true);
//        $("#ccc3Id").prop("checked",true);
//         } else{
//             $("#ccc1Id").prop("checked",false);
//             $("#ccc2Id").prop("checked",false);
//             $("#ccc3Id").prop("checked",false);
//         }   
//            });
//});
//
////==============================================================================
//
//$(document).ready(function (){
//    ($("#cccc1Id") ).click(function (){
//    
//    if(($("#cccc1Id").prop('checked')== true) || ($("#cccc2Id").prop('checked')== true) || ($("#cccc3Id").prop('checked')== true)){
//        
//        $("#p4Id").prop("checked",true);
//             }else{
//                 $("#p4Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#cccc2Id") ).click(function (){
//    
//    if(($("#cccc1Id").prop('checked')== true) || ($("#cccc2Id").prop('checked')== true) || ($("#cccc3Id").prop('checked')== true)){
//        
//        $("#p4Id").prop("checked",true);
//             }else{
//                 $("#p4Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#cccc3Id") ).click(function (){
//    
//    if(($("#cccc1Id").prop('checked')== true) || ($("#cccc2Id").prop('checked')== true) || ($("#cccc3Id").prop('checked')== true)){
//        
//        $("#p4Id").prop("checked",true);
//             }else{
//                 $("#p4Id").prop("checked",false);
//             }
//            });
//});
//
//$(document).ready(function (){
//    ($("#p4Id") ).click(function (){
//        if($("#p4Id").prop("checked") == true){
//        $("#cccc1Id").prop("checked",true);
//        $("#cccc2Id").prop("checked",true);
//        $("#cccc3Id").prop("checked",true);
//         } else{
//             $("#cccc1Id").prop("checked",false);
//             $("#cccc2Id").prop("checked",false);
//             $("#cccc3Id").prop("checked",false);
//         }   
//            });
//});
//

$(document).ready(function () {
    $('input[type=checkbox]').click(function () {

        // if is checked
        if ($(this).is(':checked')) {

            $(this).parents('li').children('input[type=checkbox]').prop('checked', true);
            $(this).parent().find('li input[type=checkbox]').prop('checked', true);


        } else {

            $(this).parents('li').children('input[type=checkbox]').prop('checked', false);

            // uncheck all children
            $(this).parent().find('li input[type=checkbox]').prop('checked', false);
               
        }
        
           
    });
});




//$(document).ready(function () {
//    $('input[type=checkbox]').click(function () {
//
//        // if is checked
//        if ($(this).is(':checked')) {
//
//            // check all children
//            $(this).parent().find('li input[type=checkbox]').prop('checked', true);
//
//            // check all parents
//            $(this).parent().prev().prop('checked', true);
//
//        } else {
//
//            // uncheck all children
//            $(this).parent().find('li input[type=checkbox]').prop('checked', false);
//
//        }
//    });
//});

