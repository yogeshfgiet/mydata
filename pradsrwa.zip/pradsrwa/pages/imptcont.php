
<?php 
	
include('loginheader.php');



if(isset($_POST['submit'])){
	$empid=$obj->adminlogin($_POST);
	
	
}
	
?>


<!DOCTYPE html>
<html lang="en">

<head>

<script>




</script>

	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="login.php"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li class="active">Important Contact</li>
				</ul>
			</div>
		</div>
	</div>
	</section>

	
	
	    <div class="container">
		<br><br>
			<div class="col-md-12">
				<div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          <strong>  Important Contact details</strong>
                        
                        </div>
                        <div class="panel-body">
                            <div class="row">
                            <strong>Shipra Suncity Address</strong>
							 		<hr class="hr1"></hr>
									<center><span class="prodTitle">Shipra Sun City </span><br>
									Vaibhav Khand,Indirapura <br>Ghaziabad,Uttar Pradesh, India, - 201014<br>
									
									
									<b>Tel: </b>+91-2-3316592, 3312767, 3316447, 3704051/3/4<br>
									<b>Fax: </b>+91-11-2-3315645,<br>
												<b>E-mail:</b> <a href="mailto:#">interyouremail@gmail.com</a><br>
											<b>Web:</b> <a href="www.enteryouwwebsite.com">www.enteryouwwebsite.com</a>
								</center><br><br>
											
								 <strong>Contact Numbers</strong>
							 		<hr class="hr1"></hr>
									<p>Security Officer :+91 9966332255 (Day)</p>
									<p>Security Officer :+91 9966332255 (Night)</p>
									<p>Gaurd Room  :+91 9966332255 </p>
									<p>Gaurd Room  :+91 9966332255 </p>
									<p>Gaurd Room  :+91 9966332255 </p>
										<hr class="hr1"></hr>
									<p>Complain Room  :+91 9966332255, +91 9966332255, +91 9966332255 (9:00 AM To 5:00 PM)</p>
									<p>Pollice Control Room  :+91 9966332255 </p>
							 
							 
							 
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>	
				<div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Some important Website Links
                        </div>
                        <div class="panel-body">
                            <div  class="row">
                             <div class="weblink">
							 <a href="#">UP Government official Website</a><br>
							 <a href="#">Ghaziabad Nagar Nigam</a><br>
							 <a href="#">Ghaziabad District</a><br>
							 <a href="#">Delhi Metro Rail</a><br>
							 <a href="#">Indian railway</a><br>
							 <a href="#">Indian Post Ofiice</a><br>
							 <a href="#">List Of All ATM In your City  </a><br>
							 <a href="#">UP POLLICE</a><br>
							 <a href="#">Consumer Forum</a><br>
							 <a href="#">Consumer Complain</a><br>
								<a href="#">Shipra Sun City</a><br>
							 	<a href="http://www.pradsoft.com" target="blank">Website Development</a><br>
							</div>
							
                             
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
							
	
			</div>
		</div>
			
					
				
				

	<br>
	<div class="panel-footer" >
	<div class="container">
		<div class="row">
			
			<div class="col-md-4 widget">
				<h3 class="widget-title">Follow me</h3>
				<div class="widget-body">
					<h2 class="follow-me-icons">
						<a href="#" ><i class="fa fa-twitter fa-2"></i></a>
						<a href=""><i class="fa fa-dribbble fa-2"></i></a>
						<a href=""><i class="fa fa-github fa-2"></i></a>
						<a href=""><i class="fa fa-facebook fa-2"></i></a>
						<a href=""><i class="fa fa-youtube fa-2"></i></a>
						<a href=""><i class="fa fa-linkedin fa-2"></i></a>
					</h2>
				</div>
			</div>

			<div class="col-md-4 widget">
				<h3 class="widget-title">About Us</h3>
				<div class="widget-body">
					<p>
						Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with


						
						
						
						</p>
					
				</div>
			</div>

			<div class="col-md-4 widget">
				<h3 class="widget-title">Contact Details</h3>
				<div class="">
					
				<p>SC 37 Jaipuria Sunrise plaza,Indirauram <BR> Ghaziabad Uttar Pradesh	</p>
				
				</div>
					
					
					<div class="widget-body">
			
					<p>0120-4132255 </p>
						<p><a href="mailto:#">info@pradsoft.com</a></p>

						<p><a href="http://www.pradsoft.com">www.pradsoft.com</a></p>
						
					</p>	
				</div>
				</div>
			</div>

		</div> 
		
			
	
	</div>
	
	<div style="background-color: black;color: gray;" class="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy;PRADS Software Private Limited  2015 All right reserved. Powered By </span><a href="http://www.pradsoft.com" target="_blank">PRADS Software</a>
						</p>
                        <!-- 
                            All links in the footer should remain intact. 
                            Licenseing information is available at: http://bootstraptaste.com/license/
                            You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Moderna
                        -->
					</div>
				</div>
			
		</div>
	</div>
	</div>

   









