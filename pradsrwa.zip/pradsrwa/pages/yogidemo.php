<?php 
	
	
	include('loginheader.php');
	?>

<!DOCTYPE html>
<html>
	<head>
	
	<script src="gen_validatorv4.js" type="text/javascript"></script>



    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>RWA</title>
	
	
	

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
	
	
	<!-- Custom CSS  By PRADS Tech -->
    <link href="newstyle.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<meta  charset=utf-8" />
	<title></title>
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<link href="jquery.smartmarquee.css" rel="stylesheet">
	<script src="jquery.smartmarquee.js"></script>
	<script language="javascript">
		$(document).ready(function () {
			$(".example").smartmarquee();
		});
	</script> 
	<style type="text/css">
		
	</style>
</head>

<body>
	<div class="col-md-3">
				<div class="login-panel panel panel-default">
					
                    <div class="panel-heading">
							
							<h3 class="panel-title"> <strong><i class="fa fa-comment"></i>Member Feedback</strong></h3>
                    </div>
					<div  class="panel-body">
						
					
              
	<div class="smartmarquee example">
		<ul class="container1">
			<li>
				<a>Misafir - er-an</a>
				<br><a>Mirac gecesinde (göğe cıkmak) dünyanın küre oldu görülmemiş mi. Böyle söyleseydi daha inandırıcı ...</a>
				
			</li>
			<li>
				<a>Misafir - hürmüz</a><br>
				<a>Bu nasıl bir kafadır arkadaş. Hakkında suçlama olan herkes hakimler hakkında şucu bucu diye iddia ortaya atsın ...</a>
			</li>
			<li>
				<a>Misafir - Aziz Naci Doğan</a><br>
				<a>Erdem timsali yiğit insan, Gerçekte artık artık zindanda olan alçakgönüllülük anıtı, erdem timsali yiğit insan Sayın RENNAN PEKÜNLÜ</a>
			</li>
			<li>
				<a>Misafir - Tarkan</a><br>
				<a>Şimdi kendine müslümanım diyen herkes düşünsün, acaba biz mi müslümanız yoksa ...</a>
			</li>
			<li>
				<a>Misafir - AÇIKÇA</a><br>
				<a>Birileri milli merkezi kandırdı,milli merkez İP partiyi kandırdı,İP genel merkezi Perinçek'i kandırdı,hepsi ...</a>
				
			</li>
			<li>
				<a>Misafir - Efsane</a><br>
				<a>Oda Tv Bu haber ile bizim Cumhurbaskani na haksizlik ediyorsunuz.O devamli soyluyor...</a>
			</li>
			<li>
				<a>Misafir - Insan</a><br>
				<a>Bu haber olmamali...Biz hep böyle yapariz, degil mi ...</a>
			</li>
			<li>
				<a>Misafir - abdestliler imamlar</a><br>
				<a>ne4 der RTE? Biz abedstimizen eminiz...emekli gül huber köşkünde milletin paraı ile aylarca kalıyor...RTEsray ...</a>
			</li>
			<li>
				<a>Misafir - aydo</a><br>
				<a>Acaba Necdet Özel cemaatin ordumuzun tepesinde ki adamı mı? Hakim Albay Zeki Çoşan ın davası ortada. Onu mahkum ...</a>
			</li>
			<li>
				<a>Misafir - MNG</a><br>
				<a>İzmit... 80'li yıllarda endüstrinin,çalışanın ve demokrasinin başkentiydi.. Ne zaman ki gerici sağ ve sığ ...</a>
			</li>
			<li>
				<a>Misafir - adalı</a><br>
				<a>Ne içiyorsunuz lan ...</a>
			</li>
			<li>
				<a>Misafir - lumpen necati</a><br>
				<a>abi magandas saffet hakli - biz memnunuz Halifemizden elhamdullillah ...</a>
			</li>
			<li>
				<a>Misafir - teksas</a><br>
				<a>abi'cim zaten ABD çözülme projesini sapına kadar destekliyor sen nerede ...</a>
			</li>
			<li>
				<a>Misafir - gizli tanik</a><br>
				<a>abi = 2.Halife Vahdettin SAV Hz ...</a>
			</li>
			<li>
				<a>Misafir - KOROLİM</a><br>
				<a>Türkiye Cumhuriyeti Devleti içerisinde ABD'nin çıkar ve menfaatlerine hizmet etmek üzere,NATO(ABD) tarafından ...</a>
			</li>
			<li>
				<a>Misafir - KOROLİM</a><br>
				<a>Türkiye Cumhuriyeti Devleti içerisinde ABD'nin çıkar ve menfaatlerine hizmet etmek üzere,NATO(ABD) tarafından ...</a>
			</li>
			<li>
				<a>Misafir - KOROLİM</a><br>
				<a>Değişik kalemlerde ödediğimiz Vergilerimizi, Atatürk düşmanlığı yapmak,mezhep ayrımcılığı yapmak ...</a>
			</li>
		</ul>
	</div>
	  </div>
			</div>
			
			</div>
</body>
</html>


