

        <!-- Navigation -->
       
           
		   <!------by yogi
		  
			
		
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        
						  <li>
                            <a href="gallery.php"><i class="fa-fw"></i> Image Gallery</a>
                        </li>
						 
						  <li>
                            <a href="banq.php"><i class=" fa-fw"></i> Banquet hall Booking</a>
                        </li>
						  <li>
                            <a href="search.php"><i class=" fa-fw"></i> Search </a>
                        </li>
						  <li>
                            <a href="download.php"><i class=" fa-fw"></i> Download Zone</a>
                        </li>
						
						 <li>
                            <a href="eventlist.php"><i class=" fa-fw"></i>Event List</a>
                        </li>
						 <li>
                            <a href="info_board.php"><i class=" fa-fw"></i>RWA Information Board</a>
                        </li>
						 <li>
                            <a href="Bill_payment.php"><i class=" fa-fw"></i>Bill Payment</a>
                        </li>
						
						 <li>
                            <a href="rwa_contact.php"><i class=" fa-fw"></i>Telephone Directory</a>
                        </li>
						
                       
						
						
						
                        
                      
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        

        