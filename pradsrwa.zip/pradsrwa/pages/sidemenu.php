<head> <link href="style.css" rel="stylesheet">
	    <script src="../bower_components/jquery/dist/jquery.min.js"></script>
<script>



 
	
	</script>
</head>
        <!-- Navigation -->
       
           
		   <!------by yogi
		  
			
		
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li id="ram" class="active" >
                            <a class="a1" href="index.php"  ><span class="fa fa-sign-in"></span><span class="text">New Registration</span></a>
                        </li>
						  <li id="ram" class="active">
                            <a class="a1" href="gallery.php"><span class="fa fa-picture-o"></span><span class="text">Image Gallery</span></a>
                        </li>
						  <li id="ram" class="active">
                            <a class="a1" href="image.php"><i class=" fa-fw"></i> Upload Image</a>
                        </li>
						  <li id="ram" class="active">
                            <a class="a1" href="banq.php"><i class=" fa-fw"></i> Banquet hall Booking</a>
                        </li>
						  <li id="ram" class="active">
                            <a class="a1" href="search.php"><i class=" fa-fw"></i> Search </a>
                        </li >
						  <li id="ram" class="active">
                            <a class="a1" href="download.php"><i class=" fa-fw"></i> Download Zone</a>
                        </li>
						 <li id="ram" class="active">
                            <a class="a1" href="event.php"><i class=" fa-fw"></i> Add Events</a>
                        </li>
						 <li id="ram" class="active">
                            <a class="a1" href="eventlist.php"><i class=" fa-fw"></i>Event List</a>
                        </li>
						 <li id="ram" class="active">
                            <a class="a1" href="info_board.php"><i class=" fa-fw"></i>RWA Information Board</a>
                        </li >
						 <li id="ram" class="active">
                            <a class="a1" href="Bill_payment.php"><i class=" fa-fw"></i>Bill Payment</a>
                        </li>
						 <li id="ram" class="active">
                            <a class="a1" href="add_news.php"><i class=" fa-fw"></i>Add News</a>
                        </li>
						 <li id="ram" class="active">
                            <a class="a1" href="rwa_contact.php"><i class=" fa-fw"></i>Telephone Directory</a>
                        </li >
						<li id="ram" class="active">
                            <a class="a1" href="manage_directory.php"><i class=" fa-fw"></i>Manage Directory</a>
                        </li>
						
                       
						
						
						
                        
                      
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        

        